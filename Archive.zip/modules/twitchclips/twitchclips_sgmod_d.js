module.exports = {
  data: {
    name: 'twitchclips'
  },
  async execute (client) {
    console.log('[TWITCHCLIPS MODULE] Coming soon...')
  }
}
